export const NEW_ADDRESS_INTERVAL = 17;
export const NEW_TRANSACTION_INTERVAL = 2;
export const NEW_BLOCK_INTERVAL = 30;
export const TRANSACTION_FEE = 0.004;
export const BLOCK_WINNER_REWARD = 0.003;
